let a = 10
console.log("hello")