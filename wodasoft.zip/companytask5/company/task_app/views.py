from django.shortcuts import render
from .forms import ArticleForm


def add_article(request):
    template_name = 'task_app/article_form.html'
    form = ArticleForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
    context = {'form': form}
    return render(request, template_name, context=context)
