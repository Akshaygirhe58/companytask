from django import forms
from .models import Article
from .widgets import TitleField


class ArticleForm(forms.ModelForm):
    title = TitleField(required=True, label='Article Title')

    class Meta:
        model = Article
        fields = '__all__'




    class Media:
        js = ('js/functions.js',)

