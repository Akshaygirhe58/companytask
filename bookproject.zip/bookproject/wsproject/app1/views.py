from django.shortcuts import render
from .forms import ArticleForm
# from django.utils import translation


def add_article(request):
    template_name = 'app1/article_form.html'
    form = ArticleForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
    context = {'form': form}

    # translation.activate(request.user.language)
    return render(request, template_name, context=context)
