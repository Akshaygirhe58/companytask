from django import forms
from .models import Article


class MultiValueWidget(forms.MultiWidget):
    def __init__(self, *args, **kwargs):
        widgets = [
            # forms.Select(choices=Article.CHOICES),
            forms.TextInput()
        ]
        super(MultiValueWidget, self).__init__(widgets, *args, **kwargs)
        # self.widgets = [
        #     forms.Select(choices=Article.CHOICES),
        #     forms.TextInput()
        # ]

    def decompress(self, value):
        if value:
            return value.split(' ')
        return [None, None]


class TitleField(forms.MultiValueField):
    widget = MultiValueWidget(attrs={
        # 'id': 'name'
        'name'
    })

    def __init__(self, *args, **kwargs):
        fields = (
            # forms.CharField(),
            forms.CharField()
        )
        super(TitleField, self).__init__(fields, *args, **kwargs)

    def compress(self, data_list):
        return ':'.join(data_list)
