from django.db import models


class Article(models.Model):
    # CHOICES = (
    #     ('EN', 'EN'),
    #     ('FR', 'FR'),
    #     ('IN', 'IN'),
    #     ('KR', 'KR'),
    # )
    title = models.JSONField('Article Title', default=dict)
    # content = models.TextField()
    created_time = models.DateTimeField(auto_now_add=True)
    # author = models.CharField(max_length=20)
    # LANGUAGE_CHOICES = (
    #     ('en-us', 'English'),
    #     ('nl', 'Dutch'),
    # )
    #
    # language = models.CharField(default='en-us', choices=LANGUAGE_CHOICES, max_length=5)

